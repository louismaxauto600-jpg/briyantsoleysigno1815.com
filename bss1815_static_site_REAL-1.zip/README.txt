BSS 1815 — Static Website (REAL FILES, NOT EMPTY)

What this is:
- A complete static HTML/CSS/JS website with real pages and real content stored in data/content.json
- No framework, no build step, deploy anywhere (Vercel, Netlify, GitHub Pages)

Folder:
- index.html
- dirijan.html
- fanbase.html
- team-san-presyon.html
- pitit-kay.html
- css/style.css
- js/main.js
- data/content.json
- assets/images/bss-logo.svg
- assets/images/fanbase/*.svg

How to customize:
1) Edit data/content.json:
   - leadership list (name/title/photo)
   - fanbase slideshow images list

2) Replace images:
   - Put real logo at: assets/images/bss-logo.(png|jpg|svg)
   - Put fanbase photos in: assets/images/fanbase/
   - Update paths in data/content.json

Deploy to Vercel (static):
- New Project -> Import this folder/repo
- Framework preset: "Other"
- Build command: (leave empty)
- Output directory: (leave empty) or "."
- Make sure files are in the root of the project

This package is intentionally NOT "empty". Every page renders even without real photos.
