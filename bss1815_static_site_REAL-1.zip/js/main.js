async function loadJSON(url){
  const res = await fetch(url, {cache: "no-store"});
  if(!res.ok) throw new Error("Failed to load " + url);
  return await res.json();
}

function setText(id, text){
  const el = document.getElementById(id);
  if(el) el.textContent = text;
}

function renderLeadership(list){
  const wrap = document.getElementById("leadershipList");
  if(!wrap) return;
  wrap.innerHTML = "";
  for(const p of list){
    const item = document.createElement("div");
    item.className = "person";
    item.innerHTML = `
      <img src="${p.photo}" alt="${p.name}">
      <div class="meta">
        <b>${p.name}</b>
        <span>${p.title}</span>
      </div>
    `;
    wrap.appendChild(item);
  }
}

function startSlideshow(images, interval){
  const imgEl = document.getElementById("fanbaseSlide");
  if(!imgEl || !images || images.length === 0) return;
  let i = 0;
  imgEl.src = images[i];
  setInterval(() => {
    i = (i + 1) % images.length;
    imgEl.src = images[i];
  }, interval || 2500);
}

(async () => {
  const data = await loadJSON("data/content.json");

  // header
  document.title = data.site.title;
  setText("brandTitle", data.site.title);
  setText("brandTagline", data.site.tagline);

  // hero
  setText("heroHeadline", data.site.heroHeadline);
  setText("heroIntro", data.site.intro);

  // official message
  setText("officialTitle", data.officialMessage.title);
  const om = document.getElementById("officialLines");
  if(om){
    om.innerHTML = "";
    for(const line of data.officialMessage.lines){
      const div = document.createElement("div");
      div.textContent = line;
      om.appendChild(div);
    }
  }

  renderLeadership(data.leadership);
  startSlideshow(data.fanbase.images, data.fanbase.slideshowIntervalMs);

  // simple page content blocks
  const tsp = document.getElementById("tspText");
  if(tsp && data.pages?.teamSanPresyon?.text) tsp.textContent = data.pages.teamSanPresyon.text;

  const pk = document.getElementById("pkText");
  if(pk && data.pages?.pititKay?.text) pk.textContent = data.pages.pititKay.text;

})().catch(err => {
  console.error(err);
  const banner = document.getElementById("errorBanner");
  if(banner){
    banner.style.display = "block";
    banner.textContent = "ERÈ: " + err.message + " (verify 'data/content.json' exists)";
  }
});
